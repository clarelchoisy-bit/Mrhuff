import { Link } from 'react-router-dom';
import { Phone, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function CTASection() {
  return (
    <section className="py-16 md:py-20 bg-primary">
      <div className="container">
        <div className="max-w-3xl mx-auto text-center space-y-6">
          <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl font-bold text-primary-foreground">
            Request Help Now
          </h2>
          <p className="text-primary-foreground/80 text-lg max-w-xl mx-auto">
            Don't wait. Get fast, confidential help with your situation today. 
            We're here to guide you through every step.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Button 
              variant="secondary" 
              size="xl" 
              className="bg-white text-primary hover:bg-white/90"
              asChild
            >
              <Link to="/contact" className="flex items-center gap-2">
                Start Your Request
                <ArrowRight className="h-5 w-5" />
              </Link>
            </Button>
            <Button 
              variant="outline" 
              size="xl" 
              className="border-white text-white hover:bg-white/10"
              asChild
            >
              <a href="tel:239-832-5356" className="flex items-center gap-2">
                <Phone className="h-5 w-5" />
                239-832-5356
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}

import { Link } from 'react-router-dom';
import { 
  Globe, 
  Stamp, 
  Building2, 
  CreditCard, 
  Palette, 
  FileText, 
  TrendingUp,
  Shield,
  ArrowRight 
} from 'lucide-react';
import { Button } from '@/components/ui/button';

const services = [
  {
    icon: Globe,
    title: 'Immigration Services',
    description: 'Family petitions, work visas, naturalization, and more. We guide you through the process.',
    href: '/services/immigration',
  },
  {
    icon: Stamp,
    title: 'Notary Service',
    description: 'Professional notary services for documents, real estate, and legal paperwork.',
    href: '/services/notary',
  },
  {
    icon: Building2,
    title: 'Business Set Up',
    description: 'LLC, Corporation, DBA formation. Get your business started the right way.',
    href: '/services/business-setup',
  },
  {
    icon: CreditCard,
    title: 'Credit Repair',
    description: 'Remove negatives, dispute errors, and build your credit score for major purchases.',
    href: '/services/credit-fix',
  },
  {
    icon: Palette,
    title: 'Graphic Design',
    description: 'Logos, flyers, business cards, and social media graphics for your business.',
    href: '/services/graphic-design',
  },
  {
    icon: FileText,
    title: 'Tax Resolution',
    description: 'IRS letters, back taxes, payment plans, and audit help. We handle the IRS for you.',
    href: '/services/tax-resolution',
  },
  {
    icon: TrendingUp,
    title: 'Business Consulting & Funding',
    description: 'Strategic consulting and funding solutions to grow your business.',
    href: '/services/business-consulting',
  },
  {
    icon: Shield,
    title: 'Insurance Services',
    description: 'Car insurance, homeowner insurance, and more. Protect what matters most.',
    href: '/services/insurance',
  },
];

export function ServicesGrid() {
  return (
    <section className="py-16 md:py-24 bg-background">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-12 md:mb-16">
          <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
            Our Services
          </h2>
          <p className="text-muted-foreground text-lg">
            Comprehensive solutions for your tax, immigration, and business needs in Naples, FL.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <div key={service.href} className="card-service p-6 group">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center group-hover:bg-accent/30 transition-colors">
                  <service.icon className="h-6 w-6 text-accent" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-heading text-xl font-semibold text-foreground mb-2">
                    {service.title}
                  </h3>
                  <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                    {service.description}
                  </p>
                  <Button variant="outline" size="sm" asChild>
                    <Link to={service.href} className="flex items-center gap-2">
                      Get Started
                      <ArrowRight className="h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

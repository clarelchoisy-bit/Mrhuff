import { Link } from 'react-router-dom';
import { Phone, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import heroBackground from '@/assets/hero-background.webp';

export function HeroSection() {
  return (
    <section className="relative overflow-hidden py-16 md:py-24 lg:py-32">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroBackground})` }}
      />
      {/* Dark Overlay */}
      <div className="absolute inset-0 bg-black/70" />
      <div className="container relative z-10">
        <div className="max-w-3xl mx-auto text-center space-y-6 md:space-y-8">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-accent/90 rounded-full">
            <span className="text-white text-sm font-medium">$100 Coupon Available</span>
          </div>

          {/* Headline */}
          <h1 className="font-heading text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight">
            MR HUFF <span className="text-accent">CORP</span>
          </h1>

          {/* Subheadline */}
          <p className="text-base md:text-lg text-white font-semibold max-w-2xl mx-auto leading-relaxed uppercase tracking-wide text-center">
            FAST HELP WITH TAXES, IMMIGRATION, CREDIT, BUSINESS SETUP, AND MORE. LOCAL OFFICE. CONFIDENTIAL HANDLING. CLEAR NEXT STEPS.
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Button variant="gold" size="xl" asChild>
              <Link to="/contact" className="flex items-center gap-2">
                Start Your Request
                <ArrowRight className="h-5 w-5" />
              </Link>
            </Button>
            <Button variant="heroOutline" size="xl" className="border-white text-white hover:bg-white/10" asChild>
              <a href="tel:239-832-5356" className="flex items-center gap-2">
                <Phone className="h-5 w-5" />
                Call 239-832-5356
              </a>
            </Button>
          </div>

          {/* Trust indicators */}
          <div className="flex flex-wrap items-center justify-center gap-6 pt-8 text-sm text-white/70">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-400"></div>
              <span>Fast Response</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-400"></div>
              <span>Confidential</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-400"></div>
              <span>Local Naples Office</span>
            </div>
          </div>
        </div>
      </div>

    </section>
  );
}

import { MapPin, Zap, Lock, CheckCircle } from 'lucide-react';

const trustBadges = [
  { icon: MapPin, label: 'Local Naples Office' },
  { icon: Zap, label: 'Fast Response' },
  { icon: Lock, label: 'Confidential Handling' },
  { icon: CheckCircle, label: 'Clear Next Steps' },
];

const steps = [
  {
    number: '1',
    title: 'Pick Your Service',
    description: 'Choose from immigration, tax, credit, business, and more.',
  },
  {
    number: '2',
    title: 'Submit Your Details',
    description: 'Fill out a quick form with your information.',
  },
  {
    number: '3',
    title: 'We Contact You',
    description: 'Get a call back with clear next steps for your situation.',
  },
];

export function TrustSection() {
  return (
    <section className="py-16 md:py-24 bg-secondary">
      <div className="container">
        {/* Trust Badges */}
        <div className="flex flex-wrap justify-center gap-4 md:gap-6 mb-16">
          {trustBadges.map((badge) => (
            <div key={badge.label} className="trust-badge">
              <badge.icon className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium text-foreground">{badge.label}</span>
            </div>
          ))}
        </div>

        {/* 3 Step Process */}
        <div className="text-center mb-12">
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-4">
            How It Works
          </h2>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">
            Getting help is simple. Here's what to expect.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          {steps.map((step, index) => (
            <div key={step.number} className="relative text-center">
              {/* Connector line */}
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-6 left-[60%] w-[80%] h-0.5 bg-border"></div>
              )}
              
              <div className="step-number mx-auto mb-4 relative z-10">
                {step.number}
              </div>
              <h3 className="font-heading text-xl font-semibold text-foreground mb-2">
                {step.title}
              </h3>
              <p className="text-muted-foreground text-sm">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

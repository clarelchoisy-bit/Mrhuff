import { Link } from 'react-router-dom';
import { Phone, MapPin, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function ContactStrip() {
  return (
    <section className="py-16 md:py-20 bg-secondary border-t border-border">
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          {/* Contact Info */}
          <div className="space-y-6">
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground">
              Ready to Get Started?
            </h2>
            <p className="text-muted-foreground text-lg">
              Contact us today for fast, confidential help with your tax, immigration, or business needs.
            </p>
            
            <div className="space-y-4">
              <a 
                href="tel:239-832-5356"
                className="flex items-center gap-4 p-4 bg-card rounded-xl border border-border hover:border-primary/50 transition-colors group"
              >
                <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center group-hover:bg-primary/30 transition-colors">
                  <Phone className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Call Today</p>
                  <p className="font-heading text-2xl font-bold text-foreground">239-832-5356</p>
                </div>
              </a>
              
              <a 
                href="https://maps.google.com/?q=3080+Tamiami+Trl+E,+Ste.+307,+Naples,+FL"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 p-4 bg-card rounded-xl border border-border hover:border-primary/50 transition-colors group"
              >
                <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center group-hover:bg-accent/30 transition-colors">
                  <MapPin className="h-6 w-6 text-accent" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Visit Us</p>
                  <p className="font-semibold text-foreground">3080 Tamiami Trl E, Ste. 307</p>
                  <p className="text-muted-foreground">Naples, FL</p>
                </div>
              </a>
            </div>

            <Button variant="gold" size="lg" asChild>
              <Link to="/contact" className="flex items-center gap-2">
                Start Your Request
                <ArrowRight className="h-5 w-5" />
              </Link>
            </Button>
          </div>

          {/* Map Embed */}
          <div className="rounded-xl overflow-hidden border border-border h-[300px] lg:h-[400px]">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3582.2!2d-81.77!3d26.14!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjbCsDA4JzI0LjAiTiA4McKwNDYnMTIuMCJX!5e0!3m2!1sen!2sus!4v1234567890"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Mr. Huff Corporation Naples FL Location"
            ></iframe>
          </div>
        </div>
      </div>
    </section>
  );
}

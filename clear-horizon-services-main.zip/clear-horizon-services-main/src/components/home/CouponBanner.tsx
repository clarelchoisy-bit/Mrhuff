import { Link } from 'react-router-dom';
import { Tag, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function CouponBanner() {
  return (
    <section className="coupon-banner py-10 md:py-14">
      <div className="container">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-white/20 flex items-center justify-center animate-pulse-glow">
              <Tag className="h-7 w-7 text-white" />
            </div>
            <div>
              <h3 className="font-heading text-2xl md:text-3xl font-bold text-white">
                $100 Coupon Available
              </h3>
              <p className="text-accent-foreground/80 text-sm md:text-base">
                Ask when you call or submit your request. Applies to qualifying services.
              </p>
            </div>
          </div>
          <Button 
            variant="secondary" 
            size="lg" 
            className="bg-accent-foreground text-accent hover:bg-accent-foreground/90"
            asChild
          >
            <Link to="/contact" className="flex items-center gap-2">
              Claim Your Coupon
              <ArrowRight className="h-5 w-5" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
}

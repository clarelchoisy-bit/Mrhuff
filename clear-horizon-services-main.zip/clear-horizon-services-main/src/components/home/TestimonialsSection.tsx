import { Star } from 'lucide-react';

const testimonials = [
  {
    name: 'Maria G.',
    location: 'Naples, FL',
    text: 'They helped me with my immigration paperwork. Very professional and fast. Highly recommend!',
    rating: 5,
  },
  {
    name: 'Robert T.',
    location: 'Fort Myers, FL',
    text: 'Got my LLC set up quickly and they explained everything clearly. Great service.',
    rating: 5,
  },
  {
    name: 'Jennifer L.',
    location: 'Naples, FL',
    text: 'Fixed my credit issues and now I was able to buy my home. Thank you!',
    rating: 5,
  },
];

export function TestimonialsSection() {
  return (
    <section className="py-16 md:py-24 bg-background">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-4">
            What Our Clients Say
          </h2>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">
            Real feedback from real clients in Naples and Southwest Florida.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="card-service p-6">
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 fill-accent text-accent" />
                ))}
              </div>
              <p className="text-foreground mb-4 leading-relaxed">
                "{testimonial.text}"
              </p>
              <div className="text-sm">
                <span className="font-semibold text-foreground">{testimonial.name}</span>
                <span className="text-muted-foreground"> • {testimonial.location}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

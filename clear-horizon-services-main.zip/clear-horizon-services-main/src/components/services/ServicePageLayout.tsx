import { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Phone, ArrowRight, CheckCircle } from 'lucide-react';

interface ServicePageLayoutProps {
  title: string;
  subtitle: string;
  metaTitle: string;
  metaDescription: string;
  whatItIs: string;
  whoItsFor: string;
  whatYouNeed: string[];
  icon: ReactNode;
  children: ReactNode;
}

export function ServicePageLayout({
  title,
  subtitle,
  metaTitle,
  metaDescription,
  whatItIs,
  whoItsFor,
  whatYouNeed,
  icon,
  children,
}: ServicePageLayoutProps) {
  return (
    <>
      <Helmet>
        <title>{metaTitle}</title>
        <meta name="description" content={metaDescription} />
      </Helmet>
      
      <Layout>
        {/* Hero */}
        <section className="bg-hero-pattern py-12 md:py-20 relative">
          <div className="container relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-accent/20 border border-accent/30 rounded-full mb-6">
                {icon}
                <span className="text-accent text-sm font-medium">$100 Coupon Available</span>
              </div>
              <h1 className="font-heading text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4">
                {title}
              </h1>
              <p className="text-lg md:text-xl text-white/80 mb-8">
                {subtitle}
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button size="lg" className="bg-green-600 hover:bg-green-700 text-white" asChild>
                  <a href="tel:239-832-5356" className="flex items-center gap-2">
                    <Phone className="h-5 w-5" />
                    Call 239-832-5356
                  </a>
                </Button>
                <Button variant="gold" size="lg" asChild>
                  <a href="#form" className="flex items-center gap-2">
                    Submit Request
                    <ArrowRight className="h-4 w-4" />
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Service Info */}
        <section className="py-12 md:py-16 bg-background">
          <div className="container">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="card-service p-6">
                <h2 className="font-heading text-xl font-semibold text-foreground mb-3">
                  What It Is
                </h2>
                <p className="text-muted-foreground leading-relaxed">
                  {whatItIs}
                </p>
              </div>
              <div className="card-service p-6">
                <h2 className="font-heading text-xl font-semibold text-foreground mb-3">
                  Who It's For
                </h2>
                <p className="text-muted-foreground leading-relaxed">
                  {whoItsFor}
                </p>
              </div>
              <div className="card-service p-6">
                <h2 className="font-heading text-xl font-semibold text-foreground mb-3">
                  What You Need
                </h2>
                <ul className="space-y-2">
                  {whatYouNeed.map((item, index) => (
                    <li key={index} className="flex items-start gap-2 text-muted-foreground">
                      <CheckCircle className="h-4 w-4 text-primary mt-1 flex-shrink-0" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Form Section */}
        <section id="form" className="py-12 md:py-20 bg-secondary scroll-mt-20">
          <div className="container">
            <div className="max-w-2xl mx-auto">
              <div className="text-center mb-8">
                <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-3">
                  Start Your Request
                </h2>
                <p className="text-muted-foreground">
                  Fill out the form below and we'll contact you with next steps.
                </p>
              </div>
              {children}
            </div>
          </div>
        </section>

        {/* Other Services CTA */}
        <section className="py-12 md:py-16 bg-background">
          <div className="container">
            <div className="text-center">
              <h2 className="font-heading text-2xl font-bold text-foreground mb-4">
                Need Other Services?
              </h2>
              <p className="text-muted-foreground mb-6">
                We offer tax resolution, immigration, notary, business setup, credit fix, and more.
              </p>
              <Button variant="outline" size="lg" asChild>
                <Link to="/services" className="flex items-center gap-2">
                  View All Services
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </Layout>
    </>
  );
}

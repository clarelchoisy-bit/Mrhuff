import { Link } from 'react-router-dom';
import { Phone, MapPin, Clock } from 'lucide-react';
import logo from '@/assets/logo.jpeg';

const services = [
  { name: 'Immigration Services', href: '/services/immigration' },
  { name: 'Notary Service', href: '/services/notary' },
  { name: 'Business Set Up', href: '/services/business-setup' },
  { name: 'Credit Repair', href: '/services/credit-fix' },
  { name: 'Graphic Design', href: '/services/graphic-design' },
  { name: 'Tax Resolution', href: '/services/tax-resolution' },
  { name: 'Business Consulting', href: '/services/business-consulting' },
];

const quickLinks = [
  { name: 'Home', href: '/' },
  { name: 'About Us', href: '/about' },
  { name: 'Contact', href: '/contact' },
  { name: 'FAQ', href: '/faq' },
];

export function Footer() {
  return (
    <footer className="bg-secondary border-t border-border">
      <div className="container py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Brand */}
          <div className="space-y-4">
            <Link to="/" className="inline-block">
              <img src={logo} alt="Mr. Huff Corporation" className="h-16 w-auto" />
            </Link>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Your trusted partner for tax resolution, immigration, business setup, and more in Naples, FL and Southwest Florida.
            </p>
            <div className="flex items-center gap-2 text-accent font-semibold">
              <span className="text-sm">$100 Coupon Available</span>
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-heading text-lg font-semibold text-foreground mb-4">Services</h3>
            <ul className="space-y-2">
              {services.map((service) => (
                <li key={service.href}>
                  <Link
                    to={service.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {service.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-heading text-lg font-semibold text-foreground mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    to={link.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-heading text-lg font-semibold text-foreground mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li>
                <a
                  href="tel:239-832-5356"
                  className="flex items-start gap-3 text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  <Phone className="h-4 w-4 mt-0.5 text-primary" />
                  <span>239-832-5356</span>
                </a>
              </li>
              <li>
                <a
                  href="https://maps.google.com/?q=3080+Tamiami+Trl+E,+Ste.+307,+Naples,+FL"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start gap-3 text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  <MapPin className="h-4 w-4 mt-0.5 text-primary" />
                  <span>3080 Tamiami Trl E, Ste. 307<br />Naples, FL</span>
                </a>
              </li>
              <li className="flex items-start gap-3 text-sm text-muted-foreground">
                <Clock className="h-4 w-4 mt-0.5 text-primary" />
                <span>By Appointment</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-border">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} Mr. Huff Corporation. All rights reserved.
            </p>
            <p className="text-sm text-muted-foreground">
              Serving Naples, FL and Southwest Florida
            </p>
          </div>
          <div className="mt-4 text-center">
            <p className="text-sm text-muted-foreground">
              Built with{' '}
              <a href="tel:239-380-6568" className="text-primary hover:underline font-medium">
                Choisy's Group
              </a>{' '}
              | <a href="tel:239-380-6568" className="text-primary hover:underline">239-380-6568</a>
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}

import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ChevronDown, Phone, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import logo from '@/assets/logo.jpeg';

const services = [
  { name: 'Immigration Services', href: '/services/immigration' },
  { name: 'Notary Service', href: '/services/notary' },
  { name: 'Business Set Up', href: '/services/business-setup' },
  { name: 'Credit Repair', href: '/services/credit-fix' },
  { name: 'Graphic Design', href: '/services/graphic-design' },
  { name: 'Tax Resolution', href: '/services/tax-resolution' },
  { name: 'Business Consulting & Funding', href: '/services/business-consulting' },
  { name: 'Insurance Services', href: '/services/insurance' },
];

const navLinks = [
  { name: 'Home', href: '/' },
  { name: 'Services', href: '/services', hasDropdown: true },
  { name: 'About', href: '/about' },
  { name: 'Contact', href: '/contact' },
];

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [servicesOpen, setServicesOpen] = useState(false);
  const location = useLocation();

  const isActive = (href: string) => {
    if (href === '/') return location.pathname === '/';
    return location.pathname.startsWith(href);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
      <div className="container flex h-16 md:h-20 items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3">
          <img src={logo} alt="Mr. Huff Corporation" className="h-12 md:h-14 w-auto" />
          <span className="font-heading text-lg md:text-xl font-bold text-foreground">
            MR HUFF <span className="text-primary">CORP</span>
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-1">
          {navLinks.map((link) => (
            <div key={link.name} className="relative">
              {link.hasDropdown ? (
                <div
                  className="relative"
                  onMouseEnter={() => setServicesOpen(true)}
                  onMouseLeave={() => setServicesOpen(false)}
                >
                  <button
                    className={cn(
                      "flex items-center gap-1 px-4 py-2 text-sm font-medium transition-colors rounded-lg",
                      isActive(link.href)
                        ? "text-primary"
                        : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
                    )}
                  >
                    {link.name}
                    <ChevronDown className={cn("h-4 w-4 transition-transform", servicesOpen && "rotate-180")} />
                  </button>
                  
                  {servicesOpen && (
                    <div className="absolute top-full left-0 mt-1 w-64 bg-white border border-border rounded-lg shadow-xl z-50 animate-fade-in origin-top">
                      <div className="p-2">
                        {services.map((service) => (
                          <Link
                            key={service.href}
                            to={service.href}
                            className="block px-4 py-2.5 text-sm text-foreground hover:text-primary hover:bg-secondary rounded-md transition-colors"
                          >
                            {service.name}
                          </Link>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <Link
                  to={link.href}
                  className={cn(
                    "px-4 py-2 text-sm font-medium transition-colors rounded-lg",
                    isActive(link.href)
                      ? "text-primary"
                      : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
                  )}
                >
                  {link.name}
                </Link>
              )}
            </div>
          ))}
        </nav>

        {/* Desktop CTAs */}
        <div className="hidden lg:flex items-center gap-3">
          <Button variant="call" size="default" asChild>
            <a href="tel:239-832-5356" className="flex items-center gap-2">
              <Phone className="h-4 w-4" />
              <span>239-832-5356</span>
            </a>
          </Button>
          <Button variant="gold" size="default" asChild>
            <Link to="/contact" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              <span>Start Your Request</span>
            </Link>
          </Button>
        </div>

        {/* Mobile Menu Toggle */}
        <button
          className="lg:hidden p-2 text-foreground"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label="Toggle menu"
        >
          {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-border bg-background animate-fade-in">
          <div className="container py-4 space-y-2">
            {navLinks.map((link) => (
              <div key={link.name}>
                {link.hasDropdown ? (
                  <div>
                    <button
                      onClick={() => setServicesOpen(!servicesOpen)}
                      className="flex items-center justify-between w-full px-4 py-3 text-base font-medium text-foreground"
                    >
                      {link.name}
                      <ChevronDown className={cn("h-5 w-5 transition-transform", servicesOpen && "rotate-180")} />
                    </button>
                    {servicesOpen && (
                      <div className="pl-4 space-y-1 pb-2">
                        {services.map((service) => (
                          <Link
                            key={service.href}
                            to={service.href}
                            onClick={() => setMobileMenuOpen(false)}
                            className="block px-4 py-2.5 text-sm text-muted-foreground hover:text-primary"
                          >
                            {service.name}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <Link
                    to={link.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className={cn(
                      "block px-4 py-3 text-base font-medium",
                      isActive(link.href) ? "text-primary" : "text-foreground"
                    )}
                  >
                    {link.name}
                  </Link>
                )}
              </div>
            ))}
            
            <div className="pt-4 space-y-3 border-t border-border">
              <Button variant="gold" size="lg" className="w-full" asChild>
                <Link to="/contact" onClick={() => setMobileMenuOpen(false)}>
                  Start Your Request
                </Link>
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}

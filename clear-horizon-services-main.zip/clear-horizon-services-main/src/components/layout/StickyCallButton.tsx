import { Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function StickyCallButton() {
  return (
    <div className="sticky-call-button">
      <Button variant="callSticky" asChild>
        <a href="tel:239-832-5356" className="flex items-center justify-center gap-3">
          <Phone className="h-5 w-5" />
          <span>Call Now: 239-832-5356</span>
        </a>
      </Button>
    </div>
  );
}

import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { HelmetProvider } from "react-helmet-async";
import Index from "./pages/Index";
import About from "./pages/About";
import Contact from "./pages/Contact";
import FAQ from "./pages/FAQ";
import ThankYou from "./pages/ThankYou";
import Services from "./pages/Services";
import ImmigrationServices from "./pages/services/ImmigrationServices";
import NotaryService from "./pages/services/NotaryService";
import BusinessSetup from "./pages/services/BusinessSetup";
import CreditFix from "./pages/services/CreditFix";
import GraphicDesign from "./pages/services/GraphicDesign";
import TaxResolution from "./pages/services/TaxResolution";
import BusinessConsulting from "./pages/services/BusinessConsulting";
import InsuranceServices from "./pages/services/InsuranceServices";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <HelmetProvider>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/faq" element={<FAQ />} />
            <Route path="/thank-you" element={<ThankYou />} />
            <Route path="/services" element={<Services />} />
            <Route path="/services/immigration" element={<ImmigrationServices />} />
            <Route path="/services/notary" element={<NotaryService />} />
            <Route path="/services/business-setup" element={<BusinessSetup />} />
            <Route path="/services/credit-fix" element={<CreditFix />} />
            <Route path="/services/graphic-design" element={<GraphicDesign />} />
            <Route path="/services/tax-resolution" element={<TaxResolution />} />
            <Route path="/services/business-consulting" element={<BusinessConsulting />} />
            <Route path="/services/insurance" element={<InsuranceServices />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  </HelmetProvider>
);

export default App;

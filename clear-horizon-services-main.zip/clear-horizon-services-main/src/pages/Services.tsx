import { Helmet } from 'react-helmet-async';
import { Layout } from '@/components/layout/Layout';
import { ServicesGrid } from '@/components/home/ServicesGrid';
import { CouponBanner } from '@/components/home/CouponBanner';
import { CTASection } from '@/components/home/CTASection';

const Services = () => {
  return (
    <>
      <Helmet>
        <title>Our Services | Mr. Huff Corporation Naples FL</title>
        <meta 
          name="description" 
          content="Mr. Huff Corporation in Naples FL: tax resolution, immigration services, notary, credit fix, business setup, graphic design, and business consulting. Call 239-832-5356." 
        />
      </Helmet>
      
      <Layout>
        {/* Hero */}
        <section className="bg-hero-pattern py-12 md:py-16 relative">
          <div className="container relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="font-heading text-4xl md:text-5xl font-bold text-foreground mb-4">
                Our <span className="text-primary">Services</span>
              </h1>
              <p className="text-lg text-muted-foreground">
                Comprehensive solutions for tax, immigration, business, and personal needs in Naples, FL.
              </p>
            </div>
          </div>
        </section>

        <ServicesGrid />
        <CouponBanner />
        <CTASection />
      </Layout>
    </>
  );
};

export default Services;

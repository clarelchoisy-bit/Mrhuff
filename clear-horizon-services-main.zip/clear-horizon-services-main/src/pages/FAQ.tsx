import { Helmet } from 'react-helmet-async';
import { Layout } from '@/components/layout/Layout';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { CTASection } from '@/components/home/CTASection';

const faqs = [
  {
    question: "Do you offer tax services in Naples FL?",
    answer: "Yes! We provide comprehensive tax services in Naples, FL and throughout Southwest Florida. Our local office is conveniently located at 3080 Tamiami Trl E, Ste. 307. We handle tax resolution, IRS letters, back taxes, payment plans, and more."
  },
  {
    question: "How fast do you respond?",
    answer: "We pride ourselves on fast response times. For most inquiries, you'll hear back from us within the same business day. For urgent matters, we recommend calling us directly at 239-832-5356."
  },
  {
    question: "What do I need to bring for notary?",
    answer: "For notary services, please bring: a valid government-issued photo ID (driver's license, passport, or state ID), the documents that need to be notarized, and all signers who need to be present. If you're unsure about anything, call us beforehand and we'll guide you."
  },
  {
    question: "Can you help with IRS letters?",
    answer: "Absolutely. We specialize in tax resolution and handle all types of IRS correspondence. Whether you've received a notice about back taxes, a payment plan, an audit, or a garnishment, we can help you respond properly and work towards a resolution."
  },
  {
    question: "Can I start my business setup online?",
    answer: "Yes! You can begin your business setup process by filling out our online intake form. We'll review your information and contact you to discuss the next steps for forming your LLC, Corporation, DBA, or Nonprofit. We handle everything from registration to EIN applications."
  },
  {
    question: "How does credit fix work?",
    answer: "Our credit fix service starts with a review of your credit report to identify negative items, errors, and areas for improvement. We then work to dispute inaccurate information with the credit bureaus, negotiate with creditors when appropriate, and provide guidance on building positive credit history. The goal is to help you qualify for major purchases like homes and cars."
  },
  {
    question: "What immigration services do you offer?",
    answer: "We assist with family petitions, work-related immigration, adjustment of status, naturalization, visa applications, asylum-related matters, and more. We guide you through the paperwork and help ensure your application is complete and properly filed."
  },
  {
    question: "Is there a fee for the initial consultation?",
    answer: "Contact us to discuss your situation. Many of our services start with a free initial review to understand your needs and provide a clear quote. Don't forget to ask about our $100 coupon for qualifying services!"
  },
  {
    question: "Do you serve areas outside Naples?",
    answer: "Yes! While our office is in Naples, we serve clients throughout Southwest Florida, including Fort Myers, Marco Island, Bonita Springs, Estero, and the surrounding areas. Many services can also be handled remotely."
  },
];

const FAQ = () => {
  return (
    <>
      <Helmet>
        <title>FAQ | Mr. Huff Corporation Naples FL</title>
        <meta 
          name="description" 
          content="Frequently asked questions about Mr. Huff Corporation in Naples, FL. Learn about our tax resolution, notary, immigration, credit fix, and business services." 
        />
      </Helmet>
      
      <Layout>
        {/* Hero */}
        <section className="bg-hero-pattern py-12 md:py-16 relative">
          <div className="container relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="font-heading text-4xl md:text-5xl font-bold text-foreground mb-4">
                Frequently Asked <span className="text-primary">Questions</span>
              </h1>
              <p className="text-lg text-muted-foreground">
                Find answers to common questions about our services.
              </p>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-12 md:py-20 bg-background">
          <div className="container">
            <div className="max-w-3xl mx-auto">
              <Accordion type="single" collapsible className="space-y-4">
                {faqs.map((faq, index) => (
                  <AccordionItem 
                    key={index} 
                    value={`item-${index}`}
                    className="bg-card border border-border rounded-xl px-6 data-[state=open]:border-primary/50"
                  >
                    <AccordionTrigger className="text-left font-heading text-lg font-semibold text-foreground hover:text-primary hover:no-underline py-5">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground pb-5 leading-relaxed">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </div>
        </section>

        <CTASection />
      </Layout>
    </>
  );
};

export default FAQ;

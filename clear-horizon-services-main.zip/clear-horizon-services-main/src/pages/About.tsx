import { Helmet } from 'react-helmet-async';
import { Layout } from '@/components/layout/Layout';
import { Users, Award, Heart, Clock } from 'lucide-react';

const values = [
  {
    icon: Users,
    title: 'Client Focused',
    description: 'Your needs come first. We listen, understand, and deliver solutions tailored to your situation.',
  },
  {
    icon: Award,
    title: 'Professional Excellence',
    description: 'Our team brings expertise and professionalism to every case, ensuring quality results.',
  },
  {
    icon: Heart,
    title: 'Community Commitment',
    description: 'Proudly serving Naples and Southwest Florida with integrity and care.',
  },
  {
    icon: Clock,
    title: 'Fast Turnaround',
    description: 'We understand urgency. Get quick responses and timely service for all your needs.',
  },
];

const About = () => {
  return (
    <>
      <Helmet>
        <title>About Us | Mr. Huff Corporation Naples FL</title>
        <meta 
          name="description" 
          content="Learn about Mr. Huff Corporation in Naples, FL. Your trusted local partner for tax resolution, immigration, business setup, and more. Serving Southwest Florida." 
        />
      </Helmet>
      
      <Layout>
        {/* Hero */}
        <section className="bg-hero-pattern py-16 md:py-24 relative">
          <div className="container relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="font-heading text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
                About <span className="text-accent">Mr. Huff Corporation</span>
              </h1>
              <p className="text-lg md:text-xl text-white/80">
                Your trusted partner for tax, immigration, and business services in Naples, FL and Southwest Florida.
              </p>
            </div>
          </div>
        </section>

        {/* About Content */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container">
            <div className="max-w-3xl mx-auto">
              <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-6">
                Helping Naples Residents Navigate Complex Situations
              </h2>
              <div className="space-y-6 text-muted-foreground leading-relaxed">
                <p>
                  At Mr. Huff Corporation, we understand that dealing with taxes, immigration paperwork, credit issues, or starting a business can feel overwhelming. That is why we are here to simplify the process and guide you every step of the way.
                </p>
                <p>
                  Based in Naples, FL, we serve clients throughout Southwest Florida, including Fort Myers, Marco Island, Bonita Springs, and beyond. Our local office means you get personalized, face-to-face service when you need it.
                </p>
                <p>
                  Whether you're facing IRS letters, need help with immigration documents, want to fix your credit, or are ready to start your own business, we have the expertise and experience to help you succeed.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Values */}
        <section className="py-16 md:py-24 bg-secondary">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-4">
                Our Values
              </h2>
              <p className="text-muted-foreground text-lg max-w-xl mx-auto">
                What sets us apart is our commitment to you.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {values.map((value) => (
                <div key={value.title} className="card-service p-6 text-center">
                  <div className="w-14 h-14 rounded-xl bg-primary/20 flex items-center justify-center mx-auto mb-4">
                    <value.icon className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="font-heading text-xl font-semibold text-foreground mb-2">
                    {value.title}
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    {value.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Location */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-6">
                  Visit Our Naples Office
                </h2>
                <div className="space-y-4 text-muted-foreground">
                  <p className="text-lg">
                    <strong className="text-foreground">Address:</strong><br />
                    3080 Tamiami Trl E, Ste. 307<br />
                    Naples, FL
                  </p>
                  <p className="text-lg">
                    <strong className="text-foreground">Phone:</strong><br />
                    <a href="tel:239-832-5356" className="text-primary hover:underline">
                      239-832-5356
                    </a>
                  </p>
                  <p className="text-lg">
                    <strong className="text-foreground">Hours:</strong><br />
                    By Appointment
                  </p>
                </div>
              </div>
              
              <div className="rounded-xl overflow-hidden border border-border h-[300px] lg:h-[400px]">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3582.2!2d-81.77!3d26.14!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjbCsDA4JzI0LjAiTiA4McKwNDYnMTIuMCJX!5e0!3m2!1sen!2sus!4v1234567890"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Tax Services Naples FL Location"
                ></iframe>
              </div>
            </div>
          </div>
        </section>
      </Layout>
    </>
  );
};

export default About;

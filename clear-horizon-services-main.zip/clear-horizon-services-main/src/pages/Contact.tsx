import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Phone, MapPin, Clock, Send } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const Contact = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    toast({
      title: "Request submitted!",
      description: "We'll contact you soon.",
    });
    
    navigate('/thank-you');
  };

  return (
    <>
      <Helmet>
        <title>Contact Us | Mr. Huff Corporation Naples FL</title>
        <meta 
          name="description" 
          content="Contact Mr. Huff Corporation in Naples, FL. Call 239-832-5356 or visit us at 3080 Tamiami Trl E, Ste. 307. Fast response for tax, immigration, and business help." 
        />
      </Helmet>
      
      <Layout>
        {/* Hero */}
        <section className="bg-hero-pattern py-12 md:py-16 relative">
          <div className="container relative z-10">
            <div className="max-w-3xl mx-auto text-center">
            <h1 className="font-heading text-4xl md:text-5xl font-bold text-white mb-4">
                Contact Us
              </h1>
              <p className="text-lg text-white">
                Ready to get started? Reach out today for fast, confidential assistance.
              </p>
            </div>
          </div>
        </section>

        <section className="py-12 md:py-20 bg-background">
          <div className="container">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Contact Info */}
              <div className="space-y-8">
                <div>
                  <h2 className="font-heading text-3xl font-bold text-foreground mb-6">
                    Get In Touch
                  </h2>
                  <p className="text-muted-foreground mb-8">
                    Call us directly or fill out the form and we'll get back to you promptly.
                  </p>
                </div>

                <div className="space-y-6">
                  <a 
                    href="tel:239-832-5356"
                    className="flex items-start gap-4 p-5 bg-card rounded-xl border border-border hover:border-primary/50 transition-colors group"
                  >
                    <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center group-hover:bg-primary/30 transition-colors">
                      <Phone className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Call Today</p>
                      <p className="font-heading text-2xl font-bold text-foreground">239-832-5356</p>
                    </div>
                  </a>

                  <a 
                    href="https://maps.google.com/?q=3080+Tamiami+Trl+E,+Ste.+307,+Naples,+FL"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-start gap-4 p-5 bg-card rounded-xl border border-border hover:border-primary/50 transition-colors group"
                  >
                    <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center group-hover:bg-accent/30 transition-colors">
                      <MapPin className="h-6 w-6 text-accent" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Visit Us</p>
                      <p className="font-semibold text-foreground">3080 Tamiami Trl E, Ste. 307</p>
                      <p className="text-muted-foreground">Naples, FL</p>
                    </div>
                  </a>

                  <div className="flex items-start gap-4 p-5 bg-card rounded-xl border border-border">
                    <div className="w-12 h-12 rounded-lg bg-secondary flex items-center justify-center">
                      <Clock className="h-6 w-6 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Office Hours</p>
                      <p className="font-semibold text-foreground">By Appointment</p>
                    </div>
                  </div>
                </div>

                {/* Map */}
                <div className="rounded-xl overflow-hidden border border-border h-[250px]">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3582.2!2d-81.77!3d26.14!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjbCsDA4JzI0LjAiTiA4McKwNDYnMTIuMCJX!5e0!3m2!1sen!2sus!4v1234567890"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    title="Tax Services Naples FL Location"
                  ></iframe>
                </div>
              </div>

              {/* Contact Form */}
              <div className="form-section">
                <h3 className="font-heading text-2xl font-bold text-foreground mb-6">
                  Send Us a Message
                </h3>
                
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name *</Label>
                      <Input id="name" name="name" placeholder="Your name" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone *</Label>
                      <Input id="phone" name="phone" type="tel" placeholder="(239) 000-0000" required />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input id="email" name="email" type="email" placeholder="your@email.com" required />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message">Message *</Label>
                    <Textarea 
                      id="message" 
                      name="message" 
                      placeholder="How can we help you?"
                      rows={5}
                      required 
                    />
                  </div>

                  <div className="flex items-start space-x-3">
                    <Checkbox id="consent" required />
                    <Label htmlFor="consent" className="text-sm text-muted-foreground leading-relaxed">
                      I agree to be contacted about my request.
                    </Label>
                  </div>

                  <Button 
                    type="submit" 
                    variant="gold" 
                    size="lg" 
                    className="w-full"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      'Sending...'
                    ) : (
                      <>
                        <Send className="h-5 w-5" />
                        Send Message
                      </>
                    )}
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </section>
      </Layout>
    </>
  );
};

export default Contact;

import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { CheckCircle, Phone, ArrowRight } from 'lucide-react';

const ThankYou = () => {
  return (
    <>
      <Helmet>
        <title>Thank You | Mr. Huff Corporation Naples FL</title>
        <meta name="robots" content="noindex" />
      </Helmet>
      
      <Layout>
        <section className="py-20 md:py-32 bg-background">
          <div className="container">
            <div className="max-w-xl mx-auto text-center space-y-8">
              <div className="w-20 h-20 rounded-full bg-green-600/20 flex items-center justify-center mx-auto">
                <CheckCircle className="h-10 w-10 text-green-500" />
              </div>
              
              <div>
                <h1 className="font-heading text-4xl md:text-5xl font-bold text-foreground mb-4">
                  Request Received!
                </h1>
                <p className="text-xl text-muted-foreground">
                  Thank you for contacting Mr. Huff Corporation. We'll be in touch soon.
                </p>
              </div>

              <div className="bg-card border border-border rounded-xl p-6 space-y-4">
                <p className="text-foreground font-medium">
                  What happens next?
                </p>
                <ul className="text-left text-muted-foreground space-y-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <span>Our team will review your request</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <span>We'll contact you within 1 business day</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <span>We'll discuss next steps for your situation</span>
                  </li>
                </ul>
              </div>

              <div className="bg-accent/10 border border-accent/30 rounded-xl p-6">
                <p className="text-foreground font-semibold mb-4">
                  If it's urgent, call us now:
                </p>
                <Button variant="call" size="xl" asChild className="w-full sm:w-auto">
                  <a href="tel:239-832-5356" className="flex items-center justify-center gap-2">
                    <Phone className="h-5 w-5" />
                    239-832-5356
                  </a>
                </Button>
              </div>

              <Button variant="outline" size="lg" asChild>
                <Link to="/" className="flex items-center gap-2">
                  Return Home
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </Layout>
    </>
  );
};

export default ThankYou;

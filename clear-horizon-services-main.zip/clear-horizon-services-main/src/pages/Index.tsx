import { Helmet } from 'react-helmet-async';
import { Layout } from '@/components/layout/Layout';
import { HeroSection } from '@/components/home/HeroSection';
import { ServicesGrid } from '@/components/home/ServicesGrid';
import { CouponBanner } from '@/components/home/CouponBanner';
import { TrustSection } from '@/components/home/TrustSection';
import { TestimonialsSection } from '@/components/home/TestimonialsSection';
import { ContactStrip } from '@/components/home/ContactStrip';
import { CTASection } from '@/components/home/CTASection';

const Index = () => {
  return (
    <>
      <Helmet>
        <title>Mr. Huff Corporation | Naples FL Tax & Business Services</title>
        <meta 
          name="description" 
          content="Mr. Huff Corporation in Naples FL: tax resolution, immigration help, notary, credit fix, business setup. Fast response, local office. Call 239-832-5356 today!" 
        />
        <meta property="og:title" content="Mr. Huff Corporation | Naples FL" />
        <meta property="og:description" content="Fast help with taxes, immigration, credit, and business setup in Naples, FL. Local office, confidential handling." />
        <meta property="og:type" content="website" />
        <link rel="canonical" href="https://mrhuffcorporation.com" />
        
        {/* LocalBusiness Schema */}
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "LocalBusiness",
            "name": "Mr. Huff Corporation",
            "telephone": "239-832-5356",
            "address": {
              "@type": "PostalAddress",
              "streetAddress": "3080 Tamiami Trl E, Ste. 307",
              "addressLocality": "Naples",
              "addressRegion": "FL",
              "addressCountry": "US"
            },
            "areaServed": ["Naples", "Southwest Florida", "Fort Myers", "Marco Island"],
            "priceRange": "$$",
            "openingHours": "By Appointment"
          })}
        </script>
      </Helmet>
      
      <Layout>
        <HeroSection />
        <ServicesGrid />
        <CouponBanner />
        <TrustSection />
        <TestimonialsSection />
        <CTASection />
        <ContactStrip />
      </Layout>
    </>
  );
};

export default Index;

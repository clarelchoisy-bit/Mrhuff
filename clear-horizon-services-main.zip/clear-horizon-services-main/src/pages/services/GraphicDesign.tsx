import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Palette } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ServicePageLayout } from '@/components/services/ServicePageLayout';
import { useToast } from '@/hooks/use-toast';

const designTypes = [
  { value: 'logo', label: 'Logo' },
  { value: 'flyer', label: 'Flyer' },
  { value: 'business-card', label: 'Business card' },
  { value: 'social-media', label: 'Social media post' },
  { value: 'banner', label: 'Banner' },
  { value: 'other', label: 'Other' },
];

const contactMethods = [
  { value: 'call', label: 'Call' },
  { value: 'text', label: 'Text' },
  { value: 'email', label: 'Email' },
];

const GraphicDesign = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    toast({ title: "Request submitted!", description: "We'll contact you soon." });
    navigate('/thank-you');
  };

  return (
    <ServicePageLayout
      title="Graphic Design in Naples, FL"
      subtitle="Logos, flyers, business cards, and social media graphics."
      metaTitle="Graphic Design Naples FL | Logos, Flyers, Business Cards"
      metaDescription="Graphic design services in Naples FL. Professional logos, flyers, business cards, social media posts. Fast turnaround. Call 239-832-5356."
      whatItIs="Professional graphic design services for your business. We create logos, flyers, business cards, social media graphics, banners, and more to help your brand stand out."
      whoItsFor="Business owners, entrepreneurs, and organizations needing professional design work for marketing, branding, or everyday business materials."
      whatYouNeed={[
        'Your business name',
        'Color preferences',
        'Deadline date',
        'Inspiration images (if any)',
        'Existing logo files (if updating)',
      ]}
      icon={<Palette className="h-4 w-4 text-accent" />}
    >
      <form onSubmit={handleSubmit} className="form-section space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="name">Full Name *</Label>
            <Input id="name" name="name" placeholder="Your full name" required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">Phone *</Label>
            <Input id="phone" name="phone" type="tel" placeholder="(239) 000-0000" required />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="email">Email *</Label>
          <Input id="email" name="email" type="email" placeholder="your@email.com" required />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Preferred Contact Method *</Label>
            <Select required>
              <SelectTrigger>
                <SelectValue placeholder="Select method" />
              </SelectTrigger>
              <SelectContent>
                {contactMethods.map((method) => (
                  <SelectItem key={method.value} value={method.value}>
                    {method.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="bestTime">Best Time to Contact</Label>
            <Input id="bestTime" name="bestTime" placeholder="e.g., Mornings, After 5pm" />
          </div>
        </div>

        <div className="space-y-2">
          <Label>Design Type *</Label>
          <Select required>
            <SelectTrigger>
              <SelectValue placeholder="What do you need designed?" />
            </SelectTrigger>
            <SelectContent>
              {designTypes.map((type) => (
                <SelectItem key={type.value} value={type.value}>
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="businessName">Business Name *</Label>
          <Input id="businessName" name="businessName" placeholder="Your business name" required />
        </div>

        <div className="space-y-2">
          <Label htmlFor="colors">Colors You Want</Label>
          <Input id="colors" name="colors" placeholder="e.g., Blue and gold, bright and modern" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="deadline">Deadline Date</Label>
          <Input id="deadline" name="deadline" type="date" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="notes">Notes About Style</Label>
          <Textarea 
            id="notes" 
            name="notes" 
            placeholder="Describe the style you're looking for, any text to include, etc."
            rows={4}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="inspiration">Inspiration Images (optional)</Label>
          <Input id="inspiration" name="inspiration" type="file" accept="image/*" multiple />
        </div>

        <div className="space-y-2">
          <Label htmlFor="existingLogo">Existing Logo Files (optional)</Label>
          <Input id="existingLogo" name="existingLogo" type="file" accept="image/*,.pdf,.ai,.eps" multiple />
        </div>

        <div className="flex items-start space-x-3">
          <Checkbox id="consent" required />
          <Label htmlFor="consent" className="text-sm text-muted-foreground leading-relaxed">
            I agree to be contacted about my request.
          </Label>
        </div>

        <Button type="submit" variant="gold" size="lg" className="w-full" disabled={isSubmitting}>
          {isSubmitting ? 'Submitting...' : 'Submit Request'}
        </Button>
      </form>
    </ServicePageLayout>
  );
};

export default GraphicDesign;

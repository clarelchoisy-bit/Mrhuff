import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Building2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ServicePageLayout } from '@/components/services/ServicePageLayout';
import { useToast } from '@/hooks/use-toast';

const businessTypes = [
  { value: 'llc', label: 'LLC' },
  { value: 'corporation', label: 'Corporation' },
  { value: 'dba', label: 'DBA' },
  { value: 'nonprofit', label: 'Nonprofit' },
  { value: 'unsure', label: 'Unsure' },
];

const contactMethods = [
  { value: 'call', label: 'Call' },
  { value: 'text', label: 'Text' },
  { value: 'email', label: 'Email' },
];

const BusinessSetup = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    toast({ title: "Request submitted!", description: "We'll contact you soon." });
    navigate('/thank-you');
  };

  return (
    <ServicePageLayout
      title="Business Set Up in Naples, FL"
      subtitle="LLC, Corporation, DBA formation. Get your business started right."
      metaTitle="Business Setup Naples FL | LLC, Corporation, DBA Formation"
      metaDescription="Business setup services in Naples FL. Form your LLC, Corporation, DBA, or Nonprofit. EIN applications, operating agreements. Call 239-832-5356."
      whatItIs="We handle all the paperwork to officially form your business including LLC, Corporation, DBA, or Nonprofit. We can also help with EIN applications and operating agreements."
      whoItsFor="Entrepreneurs, small business owners, and anyone ready to start or formalize their business in Florida."
      whatYouNeed={[
        'Chosen business name (if decided)',
        'Business type preference',
        'Industry information',
        'Owner/member information',
      ]}
      icon={<Building2 className="h-4 w-4 text-accent" />}
    >
      <form onSubmit={handleSubmit} className="form-section space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="name">Full Name *</Label>
            <Input id="name" name="name" placeholder="Your full name" required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">Phone *</Label>
            <Input id="phone" name="phone" type="tel" placeholder="(239) 000-0000" required />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="email">Email *</Label>
          <Input id="email" name="email" type="email" placeholder="your@email.com" required />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Preferred Contact Method *</Label>
            <Select required>
              <SelectTrigger>
                <SelectValue placeholder="Select method" />
              </SelectTrigger>
              <SelectContent>
                {contactMethods.map((method) => (
                  <SelectItem key={method.value} value={method.value}>
                    {method.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="bestTime">Best Time to Contact</Label>
            <Input id="bestTime" name="bestTime" placeholder="e.g., Mornings, After 5pm" />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="businessName">Business Name (if chosen)</Label>
          <Input id="businessName" name="businessName" placeholder="Your desired business name" />
        </div>

        <div className="space-y-2">
          <Label>Business Type Needed *</Label>
          <Select required>
            <SelectTrigger>
              <SelectValue placeholder="Select business type" />
            </SelectTrigger>
            <SelectContent>
              {businessTypes.map((type) => (
                <SelectItem key={type.value} value={type.value}>
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="state">State of Registration *</Label>
            <Input id="state" name="state" placeholder="Florida" defaultValue="Florida" required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="industry">Industry *</Label>
            <Input id="industry" name="industry" placeholder="e.g., Consulting, Retail, Food" required />
          </div>
        </div>

        <div className="space-y-3">
          <Label>Do you need an EIN? *</Label>
          <RadioGroup defaultValue="yes" className="flex gap-6">
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="yes" id="ein-yes" />
              <Label htmlFor="ein-yes" className="font-normal">Yes</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="no" id="ein-no" />
              <Label htmlFor="ein-no" className="font-normal">No</Label>
            </div>
          </RadioGroup>
        </div>

        <div className="space-y-3">
          <Label>Do you need an operating agreement?</Label>
          <RadioGroup defaultValue="yes" className="flex gap-6">
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="yes" id="oa-yes" />
              <Label htmlFor="oa-yes" className="font-normal">Yes</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="no" id="oa-no" />
              <Label htmlFor="oa-no" className="font-normal">No</Label>
            </div>
          </RadioGroup>
        </div>

        <div className="space-y-2">
          <Label htmlFor="notes">Notes and Goals</Label>
          <Textarea 
            id="notes" 
            name="notes" 
            placeholder="Tell us about your business goals and any specific needs..."
            rows={4}
          />
        </div>

        <div className="flex items-start space-x-3">
          <Checkbox id="consent" required />
          <Label htmlFor="consent" className="text-sm text-muted-foreground leading-relaxed">
            I agree to be contacted about my request.
          </Label>
        </div>

        <Button type="submit" variant="gold" size="lg" className="w-full" disabled={isSubmitting}>
          {isSubmitting ? 'Submitting...' : 'Submit Request'}
        </Button>
      </form>
    </ServicePageLayout>
  );
};

export default BusinessSetup;

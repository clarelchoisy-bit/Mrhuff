import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Phone, Shield, Upload, CheckCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const insuranceTypes = [
  { value: 'auto', label: 'Auto Insurance' },
  { value: 'home', label: 'Home Insurance' },
  { value: 'renters', label: 'Renters Insurance' },
  { value: 'commercial', label: 'Commercial / Business Insurance' },
  { value: 'liability', label: 'General Liability' },
  { value: 'workers-comp', label: 'Workers Compensation' },
  { value: 'health', label: 'Health Insurance' },
  { value: 'life', label: 'Life Insurance' },
  { value: 'other', label: 'Other' },
];

const contactMethods = ['Call', 'Text', 'Email'];
const contactTimes = ['Morning (9am-12pm)', 'Afternoon (12pm-5pm)', 'Evening (5pm-8pm)'];

const InsuranceServices = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [insuranceType, setInsuranceType] = useState('');
  const [consent, setConsent] = useState(false);
  
  // Form data
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    email: '',
    contactMethod: '',
    contactTime: '',
    notes: '',
    // Auto fields
    vehicleYear: '',
    vehicleMake: '',
    vehicleModel: '',
    vehicleVin: '',
    hasCurrentAutoInsurance: '',
    accidentsLast3Years: '',
    // Home/Renters fields
    propertyType: '',
    ownOrRent: '',
    zipCode: '',
    propertyValue: '',
    hasCurrentHomeInsurance: '',
    // Business fields
    businessName: '',
    industry: '',
    numEmployees: '',
    yearsInBusiness: '',
    coverageNeeded: [] as string[],
    // Health fields
    healthCoverageType: '',
    numPeopleToCover: '',
    ageRange: '',
    currentlyInsuredHealth: '',
    // Life fields
    coverageGoal: '',
    coverageAmountRange: '',
    lifeAgeRange: '',
    tobaccoUse: '',
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleCoverageNeededChange = (coverage: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      coverageNeeded: checked 
        ? [...prev.coverageNeeded, coverage]
        : prev.coverageNeeded.filter(c => c !== coverage)
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!consent) {
      toast({
        title: "Consent Required",
        description: "Please agree to be contacted regarding your insurance request.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    toast({
      title: "Request Submitted!",
      description: "We'll contact you soon about your insurance quote.",
    });
    
    navigate('/thank-you');
  };

  const showAutoFields = insuranceType === 'auto';
  const showHomeFields = insuranceType === 'home' || insuranceType === 'renters';
  const showBusinessFields = insuranceType === 'commercial' || insuranceType === 'liability' || insuranceType === 'workers-comp';
  const showHealthFields = insuranceType === 'health';
  const showLifeFields = insuranceType === 'life';

  return (
    <>
      <Helmet>
        <title>Insurance Services in Naples FL | Affordable Coverage</title>
        <meta name="description" content="Get fast insurance help in Naples FL. Auto, home, business, health, and life insurance options available. Local office. Quick response." />
        <meta name="keywords" content="Insurance services Naples FL, Auto insurance Naples FL, Business insurance Naples FL, Life insurance Naples FL, Health insurance Naples FL, Commercial insurance Naples FL" />
      </Helmet>
      
      <Layout>
        {/* Hero Section with Phone */}
        <section className="bg-gradient-to-br from-primary/10 via-background to-accent/5 py-12 md:py-16">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center">
              <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6">
                <Shield className="h-4 w-4" />
                Insurance Services
              </div>
              
              <h1 className="font-heading text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6">
                Insurance Services in Naples, FL
              </h1>
              
              <p className="text-lg text-muted-foreground mb-8">
                Professional insurance services designed to protect you, your family, and your business. 
                We help you understand your options and connect you with the right coverage based on your needs and budget.
              </p>

              {/* Phone CTA - Above the fold */}
              <div className="bg-accent/10 border border-accent/30 rounded-xl p-6 inline-block">
                <p className="text-foreground font-semibold mb-3">Need immediate assistance?</p>
                <Button variant="call" size="xl" asChild>
                  <a href="tel:239-832-5356" className="flex items-center gap-2">
                    <Phone className="h-5 w-5" />
                    239-832-5356
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Form Section */}
        <section className="py-12 md:py-20 bg-background">
          <div className="container">
            <div className="max-w-2xl mx-auto">
              <div className="bg-card border border-border rounded-xl p-6 md:p-8">
                <h2 className="font-heading text-2xl font-bold text-foreground mb-2">
                  Insurance Services Intake Form
                </h2>
                <p className="text-muted-foreground mb-8">
                  Complete the form below and we'll help you find the right coverage.
                </p>

                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Basic Contact Info */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Full Name *</Label>
                      <Input
                        id="fullName"
                        value={formData.fullName}
                        onChange={(e) => handleInputChange('fullName', e.target.value)}
                        required
                        placeholder="John Doe"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number *</Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => handleInputChange('phone', e.target.value)}
                        required
                        placeholder="(239) 555-0123"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      required
                      placeholder="john@example.com"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Preferred Contact Method *</Label>
                      <Select value={formData.contactMethod} onValueChange={(v) => handleInputChange('contactMethod', v)} required>
                        <SelectTrigger>
                          <SelectValue placeholder="Select method" />
                        </SelectTrigger>
                        <SelectContent>
                          {contactMethods.map(method => (
                            <SelectItem key={method} value={method.toLowerCase()}>{method}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Best Time to Contact *</Label>
                      <Select value={formData.contactTime} onValueChange={(v) => handleInputChange('contactTime', v)} required>
                        <SelectTrigger>
                          <SelectValue placeholder="Select time" />
                        </SelectTrigger>
                        <SelectContent>
                          {contactTimes.map(time => (
                            <SelectItem key={time} value={time.toLowerCase()}>{time}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Insurance Type */}
                  <div className="space-y-2">
                    <Label>Insurance Type Needed *</Label>
                    <Select value={insuranceType} onValueChange={setInsuranceType} required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select insurance type" />
                      </SelectTrigger>
                      <SelectContent>
                        {insuranceTypes.map(type => (
                          <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Auto Insurance Fields */}
                  {showAutoFields && (
                    <div className="space-y-4 p-4 bg-secondary/30 rounded-lg border border-border">
                      <h3 className="font-semibold text-foreground">Auto Insurance Details</h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="vehicleYear">Vehicle Year *</Label>
                          <Input
                            id="vehicleYear"
                            value={formData.vehicleYear}
                            onChange={(e) => handleInputChange('vehicleYear', e.target.value)}
                            placeholder="2024"
                            required={showAutoFields}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="vehicleMake">Make *</Label>
                          <Input
                            id="vehicleMake"
                            value={formData.vehicleMake}
                            onChange={(e) => handleInputChange('vehicleMake', e.target.value)}
                            placeholder="Toyota"
                            required={showAutoFields}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="vehicleModel">Model *</Label>
                          <Input
                            id="vehicleModel"
                            value={formData.vehicleModel}
                            onChange={(e) => handleInputChange('vehicleModel', e.target.value)}
                            placeholder="Camry"
                            required={showAutoFields}
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="vehicleVin">VIN (optional)</Label>
                        <Input
                          id="vehicleVin"
                          value={formData.vehicleVin}
                          onChange={(e) => handleInputChange('vehicleVin', e.target.value)}
                          placeholder="1HGBH41JXMN109186"
                        />
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Current insurance?</Label>
                          <RadioGroup value={formData.hasCurrentAutoInsurance} onValueChange={(v) => handleInputChange('hasCurrentAutoInsurance', v)}>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="yes" id="autoInsYes" />
                              <Label htmlFor="autoInsYes" className="font-normal">Yes</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="no" id="autoInsNo" />
                              <Label htmlFor="autoInsNo" className="font-normal">No</Label>
                            </div>
                          </RadioGroup>
                        </div>
                        <div className="space-y-2">
                          <Label>Any accidents in last 3 years?</Label>
                          <RadioGroup value={formData.accidentsLast3Years} onValueChange={(v) => handleInputChange('accidentsLast3Years', v)}>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="yes" id="accYes" />
                              <Label htmlFor="accYes" className="font-normal">Yes</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="no" id="accNo" />
                              <Label htmlFor="accNo" className="font-normal">No</Label>
                            </div>
                          </RadioGroup>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Home/Renters Insurance Fields */}
                  {showHomeFields && (
                    <div className="space-y-4 p-4 bg-secondary/30 rounded-lg border border-border">
                      <h3 className="font-semibold text-foreground">
                        {insuranceType === 'home' ? 'Home' : 'Renters'} Insurance Details
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Property Type *</Label>
                          <Select value={formData.propertyType} onValueChange={(v) => handleInputChange('propertyType', v)} required={showHomeFields}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="house">House</SelectItem>
                              <SelectItem value="condo">Condo</SelectItem>
                              <SelectItem value="apartment">Apartment</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label>Own or Rent *</Label>
                          <Select value={formData.ownOrRent} onValueChange={(v) => handleInputChange('ownOrRent', v)} required={showHomeFields}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="own">Own</SelectItem>
                              <SelectItem value="rent">Rent</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="zipCode">Zip Code *</Label>
                          <Input
                            id="zipCode"
                            value={formData.zipCode}
                            onChange={(e) => handleInputChange('zipCode', e.target.value)}
                            placeholder="34102"
                            required={showHomeFields}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Estimated Property Value</Label>
                          <Select value={formData.propertyValue} onValueChange={(v) => handleInputChange('propertyValue', v)}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select range" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="under-200k">Under $200,000</SelectItem>
                              <SelectItem value="200k-400k">$200,000 - $400,000</SelectItem>
                              <SelectItem value="400k-600k">$400,000 - $600,000</SelectItem>
                              <SelectItem value="600k-1m">$600,000 - $1,000,000</SelectItem>
                              <SelectItem value="over-1m">Over $1,000,000</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label>Current insurance?</Label>
                        <RadioGroup value={formData.hasCurrentHomeInsurance} onValueChange={(v) => handleInputChange('hasCurrentHomeInsurance', v)}>
                          <div className="flex items-center space-x-4">
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="yes" id="homeInsYes" />
                              <Label htmlFor="homeInsYes" className="font-normal">Yes</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="no" id="homeInsNo" />
                              <Label htmlFor="homeInsNo" className="font-normal">No</Label>
                            </div>
                          </div>
                        </RadioGroup>
                      </div>
                    </div>
                  )}

                  {/* Business Insurance Fields */}
                  {showBusinessFields && (
                    <div className="space-y-4 p-4 bg-secondary/30 rounded-lg border border-border">
                      <h3 className="font-semibold text-foreground">Business Insurance Details</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="businessName">Business Name *</Label>
                          <Input
                            id="businessName"
                            value={formData.businessName}
                            onChange={(e) => handleInputChange('businessName', e.target.value)}
                            placeholder="ABC Company LLC"
                            required={showBusinessFields}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="industry">Industry *</Label>
                          <Input
                            id="industry"
                            value={formData.industry}
                            onChange={(e) => handleInputChange('industry', e.target.value)}
                            placeholder="Construction"
                            required={showBusinessFields}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="numEmployees">Number of Employees *</Label>
                          <Input
                            id="numEmployees"
                            value={formData.numEmployees}
                            onChange={(e) => handleInputChange('numEmployees', e.target.value)}
                            placeholder="10"
                            required={showBusinessFields}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="yearsInBusiness">Years in Business *</Label>
                          <Input
                            id="yearsInBusiness"
                            value={formData.yearsInBusiness}
                            onChange={(e) => handleInputChange('yearsInBusiness', e.target.value)}
                            placeholder="5"
                            required={showBusinessFields}
                          />
                        </div>
                      </div>
                      <div className="space-y-3">
                        <Label>Coverage Needed (select all that apply)</Label>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                          {['General Liability', 'Workers Comp', 'Commercial Auto', 'Professional Liability', 'Property Coverage'].map(coverage => (
                            <div key={coverage} className="flex items-center space-x-2">
                              <Checkbox
                                id={coverage.replace(/\s/g, '-').toLowerCase()}
                                checked={formData.coverageNeeded.includes(coverage)}
                                onCheckedChange={(checked) => handleCoverageNeededChange(coverage, checked as boolean)}
                              />
                              <Label htmlFor={coverage.replace(/\s/g, '-').toLowerCase()} className="font-normal">{coverage}</Label>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Health Insurance Fields */}
                  {showHealthFields && (
                    <div className="space-y-4 p-4 bg-secondary/30 rounded-lg border border-border">
                      <h3 className="font-semibold text-foreground">Health Insurance Details</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Individual or Family *</Label>
                          <Select value={formData.healthCoverageType} onValueChange={(v) => handleInputChange('healthCoverageType', v)} required={showHealthFields}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="individual">Individual</SelectItem>
                              <SelectItem value="family">Family</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="numPeopleToCover">Number of People to Cover *</Label>
                          <Input
                            id="numPeopleToCover"
                            value={formData.numPeopleToCover}
                            onChange={(e) => handleInputChange('numPeopleToCover', e.target.value)}
                            placeholder="2"
                            required={showHealthFields}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Approximate Age Range *</Label>
                          <Select value={formData.ageRange} onValueChange={(v) => handleInputChange('ageRange', v)} required={showHealthFields}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select range" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="18-25">18-25</SelectItem>
                              <SelectItem value="26-35">26-35</SelectItem>
                              <SelectItem value="36-45">36-45</SelectItem>
                              <SelectItem value="46-55">46-55</SelectItem>
                              <SelectItem value="56-64">56-64</SelectItem>
                              <SelectItem value="65+">65+</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label>Currently insured?</Label>
                          <RadioGroup value={formData.currentlyInsuredHealth} onValueChange={(v) => handleInputChange('currentlyInsuredHealth', v)}>
                            <div className="flex items-center space-x-4">
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="yes" id="healthInsYes" />
                                <Label htmlFor="healthInsYes" className="font-normal">Yes</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="no" id="healthInsNo" />
                                <Label htmlFor="healthInsNo" className="font-normal">No</Label>
                              </div>
                            </div>
                          </RadioGroup>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Life Insurance Fields */}
                  {showLifeFields && (
                    <div className="space-y-4 p-4 bg-secondary/30 rounded-lg border border-border">
                      <h3 className="font-semibold text-foreground">Life Insurance Details</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Coverage Goal *</Label>
                          <Select value={formData.coverageGoal} onValueChange={(v) => handleInputChange('coverageGoal', v)} required={showLifeFields}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select goal" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="final-expenses">Final Expenses</SelectItem>
                              <SelectItem value="income-replacement">Income Replacement</SelectItem>
                              <SelectItem value="mortgage-protection">Mortgage Protection</SelectItem>
                              <SelectItem value="wealth-planning">Wealth Planning</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label>Coverage Amount Range *</Label>
                          <Select value={formData.coverageAmountRange} onValueChange={(v) => handleInputChange('coverageAmountRange', v)} required={showLifeFields}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select range" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="under-100k">Under $100,000</SelectItem>
                              <SelectItem value="100k-250k">$100,000 - $250,000</SelectItem>
                              <SelectItem value="250k-500k">$250,000 - $500,000</SelectItem>
                              <SelectItem value="500k-1m">$500,000 - $1,000,000</SelectItem>
                              <SelectItem value="over-1m">Over $1,000,000</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Age Range *</Label>
                          <Select value={formData.lifeAgeRange} onValueChange={(v) => handleInputChange('lifeAgeRange', v)} required={showLifeFields}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select range" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="18-30">18-30</SelectItem>
                              <SelectItem value="31-40">31-40</SelectItem>
                              <SelectItem value="41-50">41-50</SelectItem>
                              <SelectItem value="51-60">51-60</SelectItem>
                              <SelectItem value="61-70">61-70</SelectItem>
                              <SelectItem value="70+">70+</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label>Tobacco use?</Label>
                          <RadioGroup value={formData.tobaccoUse} onValueChange={(v) => handleInputChange('tobaccoUse', v)}>
                            <div className="flex items-center space-x-4">
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="yes" id="tobaccoYes" />
                                <Label htmlFor="tobaccoYes" className="font-normal">Yes</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="no" id="tobaccoNo" />
                                <Label htmlFor="tobaccoNo" className="font-normal">No</Label>
                              </div>
                            </div>
                          </RadioGroup>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Notes */}
                  <div className="space-y-2">
                    <Label htmlFor="notes">Notes or Questions (optional)</Label>
                    <Textarea
                      id="notes"
                      value={formData.notes}
                      onChange={(e) => handleInputChange('notes', e.target.value)}
                      placeholder="Any additional information or questions..."
                      rows={4}
                    />
                  </div>

                  {/* File Upload */}
                  <div className="space-y-2">
                    <Label>Upload Documents (optional)</Label>
                    <p className="text-sm text-muted-foreground mb-2">
                      Current policy, ID, or declarations page
                    </p>
                    <div className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-primary/50 transition-colors cursor-pointer">
                      <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground">
                        Drag and drop files here, or click to browse
                      </p>
                      <input type="file" className="hidden" multiple accept=".pdf,.jpg,.jpeg,.png" />
                    </div>
                  </div>

                  {/* Consent */}
                  <div className="flex items-start space-x-3 p-4 bg-muted/50 rounded-lg">
                    <Checkbox
                      id="consent"
                      checked={consent}
                      onCheckedChange={(checked) => setConsent(checked as boolean)}
                      required
                    />
                    <Label htmlFor="consent" className="text-sm font-normal leading-relaxed cursor-pointer">
                      I agree to be contacted regarding my insurance request. *
                    </Label>
                  </div>

                  {/* Submit */}
                  <Button 
                    type="submit" 
                    size="xl" 
                    className="w-full"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? 'Submitting...' : 'Request Insurance Quote'}
                  </Button>
                </form>
              </div>

              {/* Trust indicators */}
              <div className="mt-8 flex flex-wrap justify-center gap-6 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>Free quotes</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>No obligation</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>Quick response</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </Layout>
    </>
  );
};

export default InsuranceServices;

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ServicePageLayout } from '@/components/services/ServicePageLayout';
import { useToast } from '@/hooks/use-toast';

const mainGoals = [
  { value: 'buy-car', label: 'Buy a car' },
  { value: 'buy-home', label: 'Buy a home' },
  { value: 'lower-payments', label: 'Lower payments' },
  { value: 'remove-negatives', label: 'Remove negatives' },
  { value: 'build-credit', label: 'Build credit' },
];

const creditScoreRanges = [
  { value: 'under-500', label: 'Under 500' },
  { value: '500-579', label: '500 to 579' },
  { value: '580-649', label: '580 to 649' },
  { value: '650-719', label: '650 to 719' },
  { value: '720-plus', label: '720+' },
  { value: 'not-sure', label: 'Not sure' },
];

const negativeItems = [
  { id: 'collections', label: 'Collections' },
  { id: 'late-payments', label: 'Late payments' },
  { id: 'charge-offs', label: 'Charge offs' },
  { id: 'repossession', label: 'Repossession' },
  { id: 'bankruptcy', label: 'Bankruptcy' },
  { id: 'identity-issue', label: 'Identity issue' },
];

const bureaus = [
  { id: 'experian', label: 'Experian' },
  { id: 'equifax', label: 'Equifax' },
  { id: 'transunion', label: 'TransUnion' },
  { id: 'not-sure', label: 'Not sure' },
];

const contactMethods = [
  { value: 'call', label: 'Call' },
  { value: 'text', label: 'Text' },
  { value: 'email', label: 'Email' },
];

const CreditFix = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    toast({ title: "Request submitted!", description: "We'll contact you soon." });
    navigate('/thank-you');
  };

  return (
    <ServicePageLayout
      title="Credit Fix in Naples, FL"
      subtitle="Remove negatives, dispute errors, and build your credit score."
      metaTitle="Credit Fix Naples FL | Credit Repair & Score Improvement"
      metaDescription="Credit repair services in Naples FL. Remove collections, late payments, charge-offs. Improve your score to buy a home or car. Call 239-832-5356."
      whatItIs="We review your credit report, identify errors and negative items, and work to dispute inaccuracies. We help you build a stronger credit profile for major purchases."
      whoItsFor="Anyone looking to improve their credit score, whether to buy a home, car, lower interest rates, or simply clean up their credit history."
      whatYouNeed={[
        'Recent credit report (we can help you get one)',
        'List of known issues',
        'Your credit goals',
        'Time and patience for the process',
      ]}
      icon={<CreditCard className="h-4 w-4 text-accent" />}
    >
      <form onSubmit={handleSubmit} className="form-section space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="name">Full Name *</Label>
            <Input id="name" name="name" placeholder="Your full name" required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">Phone *</Label>
            <Input id="phone" name="phone" type="tel" placeholder="(239) 000-0000" required />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="email">Email *</Label>
          <Input id="email" name="email" type="email" placeholder="your@email.com" required />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Preferred Contact Method *</Label>
            <Select required>
              <SelectTrigger>
                <SelectValue placeholder="Select method" />
              </SelectTrigger>
              <SelectContent>
                {contactMethods.map((method) => (
                  <SelectItem key={method.value} value={method.value}>
                    {method.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="bestTime">Best Time to Contact</Label>
            <Input id="bestTime" name="bestTime" placeholder="e.g., Mornings, After 5pm" />
          </div>
        </div>

        <div className="space-y-2">
          <Label>Main Goal *</Label>
          <Select required>
            <SelectTrigger>
              <SelectValue placeholder="What's your main goal?" />
            </SelectTrigger>
            <SelectContent>
              {mainGoals.map((goal) => (
                <SelectItem key={goal.value} value={goal.value}>
                  {goal.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Current Credit Score Range *</Label>
          <Select required>
            <SelectTrigger>
              <SelectValue placeholder="Select your range" />
            </SelectTrigger>
            <SelectContent>
              {creditScoreRanges.map((range) => (
                <SelectItem key={range.value} value={range.value}>
                  {range.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-3">
          <Label>Negative Items (check all that apply)</Label>
          <div className="grid grid-cols-2 gap-3">
            {negativeItems.map((item) => (
              <div key={item.id} className="flex items-center space-x-2">
                <Checkbox id={item.id} />
                <Label htmlFor={item.id} className="font-normal text-sm">
                  {item.label}
                </Label>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <Label>Which bureaus are affected?</Label>
          <div className="grid grid-cols-2 gap-3">
            {bureaus.map((bureau) => (
              <div key={bureau.id} className="flex items-center space-x-2">
                <Checkbox id={bureau.id} />
                <Label htmlFor={bureau.id} className="font-normal text-sm">
                  {bureau.label}
                </Label>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="creditReport">Credit Report or Screenshots (optional)</Label>
          <Input id="creditReport" name="creditReport" type="file" accept="image/*,.pdf" multiple />
        </div>

        <div className="flex items-start space-x-3">
          <Checkbox id="consent" required />
          <Label htmlFor="consent" className="text-sm text-muted-foreground leading-relaxed">
            I agree to be contacted about my request.
          </Label>
        </div>

        <Button type="submit" variant="gold" size="lg" className="w-full" disabled={isSubmitting}>
          {isSubmitting ? 'Submitting...' : 'Submit Request'}
        </Button>
      </form>
    </ServicePageLayout>
  );
};

export default CreditFix;

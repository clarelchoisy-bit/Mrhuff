import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ServicePageLayout } from '@/components/services/ServicePageLayout';
import { useToast } from '@/hooks/use-toast';

const timeInBusiness = [
  { value: 'not-started', label: 'Not started' },
  { value: 'under-6-months', label: 'Under 6 months' },
  { value: '6-12-months', label: '6 to 12 months' },
  { value: '1-2-years', label: '1 to 2 years' },
  { value: '2-plus-years', label: '2+ years' },
];

const revenueRanges = [
  { value: '0', label: '$0' },
  { value: 'under-5000', label: 'Under $5,000' },
  { value: '5000-20000', label: '$5,000 to $20,000' },
  { value: '20000-plus', label: '$20,000+' },
];

const fundingNeeded = [
  { value: 'under-10000', label: 'Under $10,000' },
  { value: '10000-50000', label: '$10,000 to $50,000' },
  { value: '50000-plus', label: '$50,000+' },
  { value: 'not-sure', label: 'Not sure' },
];

const contactMethods = [
  { value: 'call', label: 'Call' },
  { value: 'text', label: 'Text' },
  { value: 'email', label: 'Email' },
];

const BusinessConsulting = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    toast({ title: "Request submitted!", description: "We'll contact you soon." });
    navigate('/thank-you');
  };

  return (
    <ServicePageLayout
      title="Business Consulting & Funding in Naples, FL"
      subtitle="Strategic consulting and funding solutions to grow your business."
      metaTitle="Business Consulting Naples FL | Funding & Growth Strategies"
      metaDescription="Business consulting and funding in Naples FL. Strategic advice, funding solutions, growth planning for small businesses. Call 239-832-5356."
      whatItIs="We provide strategic business consulting and help you access funding options. Whether you're starting out or looking to grow, we offer guidance on business strategy, operations, and financing."
      whoItsFor="Entrepreneurs and small business owners seeking strategic advice, growth planning, or funding to scale their operations."
      whatYouNeed={[
        'Business name and details',
        'Time in business',
        'Current revenue information',
        'Funding amount needed',
        'Business goals',
      ]}
      icon={<TrendingUp className="h-4 w-4 text-accent" />}
    >
      <form onSubmit={handleSubmit} className="form-section space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="name">Full Name *</Label>
            <Input id="name" name="name" placeholder="Your full name" required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">Phone *</Label>
            <Input id="phone" name="phone" type="tel" placeholder="(239) 000-0000" required />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="email">Email *</Label>
          <Input id="email" name="email" type="email" placeholder="your@email.com" required />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Preferred Contact Method *</Label>
            <Select required>
              <SelectTrigger>
                <SelectValue placeholder="Select method" />
              </SelectTrigger>
              <SelectContent>
                {contactMethods.map((method) => (
                  <SelectItem key={method.value} value={method.value}>
                    {method.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="bestTime">Best Time to Contact</Label>
            <Input id="bestTime" name="bestTime" placeholder="e.g., Mornings, After 5pm" />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="businessName">Business Name *</Label>
          <Input id="businessName" name="businessName" placeholder="Your business name" required />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Time in Business *</Label>
            <Select required>
              <SelectTrigger>
                <SelectValue placeholder="Select time" />
              </SelectTrigger>
              <SelectContent>
                {timeInBusiness.map((time) => (
                  <SelectItem key={time.value} value={time.value}>
                    {time.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Monthly Revenue Range *</Label>
            <Select required>
              <SelectTrigger>
                <SelectValue placeholder="Select range" />
              </SelectTrigger>
              <SelectContent>
                {revenueRanges.map((range) => (
                  <SelectItem key={range.value} value={range.value}>
                    {range.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label>Funding Needed *</Label>
          <Select required>
            <SelectTrigger>
              <SelectValue placeholder="How much funding do you need?" />
            </SelectTrigger>
            <SelectContent>
              {fundingNeeded.map((amount) => (
                <SelectItem key={amount.value} value={amount.value}>
                  {amount.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="mainGoal">Main Goal *</Label>
          <Textarea 
            id="mainGoal" 
            name="mainGoal" 
            placeholder="What are your main business goals? What do you want to achieve?"
            rows={4}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="bankStatements">Bank Statements (optional)</Label>
          <Input id="bankStatements" name="bankStatements" type="file" accept=".pdf,image/*" multiple />
        </div>

        <div className="space-y-2">
          <Label htmlFor="businessDocs">Business Documents (optional)</Label>
          <Input id="businessDocs" name="businessDocs" type="file" accept=".pdf,image/*,.doc,.docx" multiple />
        </div>

        <div className="flex items-start space-x-3">
          <Checkbox id="consent" required />
          <Label htmlFor="consent" className="text-sm text-muted-foreground leading-relaxed">
            I agree to be contacted about my request.
          </Label>
        </div>

        <Button type="submit" variant="gold" size="lg" className="w-full" disabled={isSubmitting}>
          {isSubmitting ? 'Submitting...' : 'Submit Request'}
        </Button>
      </form>
    </ServicePageLayout>
  );
};

export default BusinessConsulting;

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ServicePageLayout } from '@/components/services/ServicePageLayout';
import { useToast } from '@/hooks/use-toast';

const immigrationNeeds = [
  { value: 'family-petition', label: 'Family petition' },
  { value: 'work-related', label: 'Work related' },
  { value: 'adjustment-status', label: 'Adjustment of status' },
  { value: 'naturalization', label: 'Naturalization' },
  { value: 'visa-help', label: 'Visa help' },
  { value: 'asylum', label: 'Asylum related' },
  { value: 'other', label: 'Other' },
];

const contactMethods = [
  { value: 'call', label: 'Call' },
  { value: 'text', label: 'Text' },
  { value: 'email', label: 'Email' },
];

const ImmigrationServices = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    toast({ title: "Request submitted!", description: "We'll contact you soon." });
    navigate('/thank-you');
  };

  return (
    <ServicePageLayout
      title="Immigration Services in Naples, FL"
      subtitle="Expert guidance for family petitions, visas, naturalization, and more."
      metaTitle="Immigration Services Naples FL | Family Petitions & Visa Help"
      metaDescription="Immigration services in Naples FL. Family petitions, work visas, naturalization, asylum help. Local office, confidential handling. Call 239-832-5356."
      whatItIs="We help with immigration paperwork, applications, and filings. From family sponsorships to work visas and naturalization, we guide you through the complex process step by step."
      whoItsFor="Individuals and families seeking to immigrate, adjust status, apply for visas, pursue naturalization, or address other immigration needs."
      whatYouNeed={[
        'Valid passport or ID',
        'Any immigration notices or letters',
        'Supporting documents for your case',
        'Information about family members if applicable',
      ]}
      icon={<Globe className="h-4 w-4 text-accent" />}
    >
      <form onSubmit={handleSubmit} className="form-section space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="name">Full Name *</Label>
            <Input id="name" name="name" placeholder="Your full name" required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">Phone *</Label>
            <Input id="phone" name="phone" type="tel" placeholder="(239) 000-0000" required />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="email">Email *</Label>
          <Input id="email" name="email" type="email" placeholder="your@email.com" required />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Preferred Contact Method *</Label>
            <Select required>
              <SelectTrigger>
                <SelectValue placeholder="Select method" />
              </SelectTrigger>
              <SelectContent>
                {contactMethods.map((method) => (
                  <SelectItem key={method.value} value={method.value}>
                    {method.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="bestTime">Best Time to Contact</Label>
            <Input id="bestTime" name="bestTime" placeholder="e.g., Mornings, After 5pm" />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="location">Current Location (City, State, Country) *</Label>
          <Input id="location" name="location" placeholder="Naples, FL, USA" required />
        </div>

        <div className="space-y-2">
          <Label>Immigration Need *</Label>
          <Select required>
            <SelectTrigger>
              <SelectValue placeholder="Select your need" />
            </SelectTrigger>
            <SelectContent>
              {immigrationNeeds.map((need) => (
                <SelectItem key={need.value} value={need.value}>
                  {need.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="deadline">Deadline Date (if any)</Label>
          <Input id="deadline" name="deadline" type="date" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Short Description of Situation *</Label>
          <Textarea 
            id="description" 
            name="description" 
            placeholder="Briefly describe your immigration situation and goals..."
            rows={4}
            required 
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="passport">Passport or ID (optional)</Label>
          <Input id="passport" name="passport" type="file" accept="image/*,.pdf" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="notices">Immigration Notice Letters (optional)</Label>
          <Input id="notices" name="notices" type="file" accept="image/*,.pdf" multiple />
        </div>

        <div className="flex items-start space-x-3">
          <Checkbox id="consent" required />
          <Label htmlFor="consent" className="text-sm text-muted-foreground leading-relaxed">
            I agree to be contacted about my request.
          </Label>
        </div>

        <Button type="submit" variant="gold" size="lg" className="w-full" disabled={isSubmitting}>
          {isSubmitting ? 'Submitting...' : 'Submit Request'}
        </Button>
      </form>
    </ServicePageLayout>
  );
};

export default ImmigrationServices;

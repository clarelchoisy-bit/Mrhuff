import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Stamp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ServicePageLayout } from '@/components/services/ServicePageLayout';
import { useToast } from '@/hooks/use-toast';

const contactMethods = [
  { value: 'call', label: 'Call' },
  { value: 'text', label: 'Text' },
  { value: 'email', label: 'Email' },
];

const NotaryService = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    toast({ title: "Request submitted!", description: "We'll contact you soon." });
    navigate('/thank-you');
  };

  return (
    <ServicePageLayout
      title="Notary Service in Naples, FL"
      subtitle="Professional notary services for documents, real estate, and legal paperwork."
      metaTitle="Notary Service Naples FL | Document Notarization"
      metaDescription="Notary services in Naples FL. Professional document notarization for real estate, legal papers, and more. Local office. Call 239-832-5356 for appointment."
      whatItIs="Official notarization of documents including real estate papers, legal documents, affidavits, powers of attorney, and more. We ensure proper witnessing and authentication."
      whoItsFor="Anyone needing documents officially notarized including individuals, businesses, real estate transactions, legal filings, and personal matters."
      whatYouNeed={[
        'Valid government-issued photo ID',
        'The documents to be notarized',
        'All signers must be present',
        'Documents must be unsigned until appointment',
      ]}
      icon={<Stamp className="h-4 w-4 text-accent" />}
    >
      <form onSubmit={handleSubmit} className="form-section space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="name">Full Name *</Label>
            <Input id="name" name="name" placeholder="Your full name" required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">Phone *</Label>
            <Input id="phone" name="phone" type="tel" placeholder="(239) 000-0000" required />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="email">Email *</Label>
          <Input id="email" name="email" type="email" placeholder="your@email.com" required />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Preferred Contact Method *</Label>
            <Select required>
              <SelectTrigger>
                <SelectValue placeholder="Select method" />
              </SelectTrigger>
              <SelectContent>
                {contactMethods.map((method) => (
                  <SelectItem key={method.value} value={method.value}>
                    {method.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="bestTime">Best Time to Contact</Label>
            <Input id="bestTime" name="bestTime" placeholder="e.g., Mornings, After 5pm" />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="documentType">Document Type *</Label>
          <Input id="documentType" name="documentType" placeholder="e.g., Power of Attorney, Real Estate Deed" required />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="numDocuments">Number of Documents *</Label>
            <Input id="numDocuments" name="numDocuments" type="number" min="1" placeholder="1" required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="numSigners">Number of Signers *</Label>
            <Input id="numSigners" name="numSigners" type="number" min="1" placeholder="1" required />
          </div>
        </div>

        <div className="space-y-3">
          <Label>Do all signers have valid ID? *</Label>
          <RadioGroup defaultValue="yes" className="flex gap-6">
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="yes" id="id-yes" />
              <Label htmlFor="id-yes" className="font-normal">Yes</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="no" id="id-no" />
              <Label htmlFor="id-no" className="font-normal">No</Label>
            </div>
          </RadioGroup>
        </div>

        <div className="space-y-2">
          <Label>Appointment Preference</Label>
          <p className="text-sm text-muted-foreground">In-office appointment at our Naples location</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="requestedDate">Requested Date</Label>
            <Input id="requestedDate" name="requestedDate" type="date" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="requestedTime">Requested Time</Label>
            <Input id="requestedTime" name="requestedTime" type="time" />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="documentPreview">Document Preview (optional)</Label>
          <Input id="documentPreview" name="documentPreview" type="file" accept="image/*,.pdf" />
        </div>

        <div className="flex items-start space-x-3">
          <Checkbox id="consent" required />
          <Label htmlFor="consent" className="text-sm text-muted-foreground leading-relaxed">
            I agree to be contacted about my request.
          </Label>
        </div>

        <Button type="submit" variant="gold" size="lg" className="w-full" disabled={isSubmitting}>
          {isSubmitting ? 'Submitting...' : 'Submit Request'}
        </Button>
      </form>
    </ServicePageLayout>
  );
};

export default NotaryService;

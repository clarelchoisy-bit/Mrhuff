import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ServicePageLayout } from '@/components/services/ServicePageLayout';
import { useToast } from '@/hooks/use-toast';

const issueTypes = [
  { value: 'irs-letter', label: 'IRS letter' },
  { value: 'back-taxes', label: 'Back taxes' },
  { value: 'payment-plan', label: 'Payment plan' },
  { value: 'garnishment', label: 'Garnishment' },
  { value: 'audit-help', label: 'Audit help' },
  { value: 'amended-return', label: 'Amended return' },
  { value: 'other', label: 'Other' },
];

const amountOwedRanges = [
  { value: 'under-5000', label: 'Under $5,000' },
  { value: '5000-10000', label: '$5,000 to $10,000' },
  { value: '10000-25000', label: '$10,000 to $25,000' },
  { value: '25000-plus', label: '$25,000+' },
  { value: 'not-sure', label: 'Not sure' },
];

const contactMethods = [
  { value: 'call', label: 'Call' },
  { value: 'text', label: 'Text' },
  { value: 'email', label: 'Email' },
];

const TaxResolution = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    toast({ title: "Request submitted!", description: "We'll contact you soon." });
    navigate('/thank-you');
  };

  return (
    <ServicePageLayout
      title="Tax Resolution in Naples, FL"
      subtitle="IRS letters, back taxes, payment plans, and audit help."
      metaTitle="Tax Resolution Naples FL | IRS Help, Back Taxes, Payment Plans"
      metaDescription="Tax resolution services in Naples FL. Help with IRS letters, back taxes, payment plans, garnishments, audits. Local office. Call 239-832-5356."
      whatItIs="We help you resolve tax issues with the IRS and state agencies. Whether you've received letters, owe back taxes, need a payment plan, or are facing an audit, we can help."
      whoItsFor="Individuals and businesses dealing with IRS letters, back taxes, unfiled returns, garnishments, audits, or any tax-related problems."
      whatYouNeed={[
        'IRS or state letters you\'ve received',
        'Tax years involved',
        'Estimated amount owed',
        'Prior tax returns (if available)',
      ]}
      icon={<FileText className="h-4 w-4 text-accent" />}
    >
      <form onSubmit={handleSubmit} className="form-section space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="name">Full Name *</Label>
            <Input id="name" name="name" placeholder="Your full name" required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">Phone *</Label>
            <Input id="phone" name="phone" type="tel" placeholder="(239) 000-0000" required />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="email">Email *</Label>
          <Input id="email" name="email" type="email" placeholder="your@email.com" required />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Preferred Contact Method *</Label>
            <Select required>
              <SelectTrigger>
                <SelectValue placeholder="Select method" />
              </SelectTrigger>
              <SelectContent>
                {contactMethods.map((method) => (
                  <SelectItem key={method.value} value={method.value}>
                    {method.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="bestTime">Best Time to Contact</Label>
            <Input id="bestTime" name="bestTime" placeholder="e.g., Mornings, After 5pm" />
          </div>
        </div>

        <div className="space-y-2">
          <Label>Issue Type *</Label>
          <Select required>
            <SelectTrigger>
              <SelectValue placeholder="What's your tax issue?" />
            </SelectTrigger>
            <SelectContent>
              {issueTypes.map((issue) => (
                <SelectItem key={issue.value} value={issue.value}>
                  {issue.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="taxYears">Tax Years Involved *</Label>
          <Input id="taxYears" name="taxYears" placeholder="e.g., 2021, 2022, 2023" required />
        </div>

        <div className="space-y-2">
          <Label>Estimated Amount Owed *</Label>
          <Select required>
            <SelectTrigger>
              <SelectValue placeholder="Select range" />
            </SelectTrigger>
            <SelectContent>
              {amountOwedRanges.map((range) => (
                <SelectItem key={range.value} value={range.value}>
                  {range.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-3">
          <Label>Have you received official notices? *</Label>
          <RadioGroup defaultValue="yes" className="flex gap-6">
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="yes" id="notices-yes" />
              <Label htmlFor="notices-yes" className="font-normal">Yes</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="no" id="notices-no" />
              <Label htmlFor="notices-no" className="font-normal">No</Label>
            </div>
          </RadioGroup>
        </div>

        <div className="space-y-2">
          <Label htmlFor="irsLetters">IRS or State Letters (recommended)</Label>
          <Input id="irsLetters" name="irsLetters" type="file" accept="image/*,.pdf" multiple />
          <p className="text-xs text-muted-foreground">
            Upload any letters you've received from the IRS or state tax agency.
          </p>
        </div>

        <div className="flex items-start space-x-3">
          <Checkbox id="consent" required />
          <Label htmlFor="consent" className="text-sm text-muted-foreground leading-relaxed">
            I agree to be contacted about my request.
          </Label>
        </div>

        <Button type="submit" variant="gold" size="lg" className="w-full" disabled={isSubmitting}>
          {isSubmitting ? 'Submitting...' : 'Submit Request'}
        </Button>
      </form>
    </ServicePageLayout>
  );
};

export default TaxResolution;

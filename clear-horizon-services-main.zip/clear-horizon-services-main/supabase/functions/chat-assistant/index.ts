import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const SYSTEM_PROMPT = `You are the friendly and knowledgeable virtual assistant for Mr. Huff Corporation, a professional services company located in Naples, FL (3080 Tamiami Trl E, Ste. 307). Your role is to help visitors learn about services, answer questions, and encourage them to schedule a consultation.

CONTACT INFORMATION:
- Phone: 239-832-5356
- Location: 3080 Tamiami Trl E, Ste. 307, Naples, FL
- Hours: By Appointment

SERVICES OFFERED:

1. TAX RESOLUTION
- Help with IRS problems, back taxes, tax liens, and levies
- Penalty abatement and payment plans
- Offer in Compromise assistance
- Tax preparation and planning

2. IMMIGRATION SERVICES
- Visa applications and renewals
- Green card applications
- Citizenship and naturalization
- Work permits and employment authorization
- Family-based immigration petitions
- DACA renewals

3. BUSINESS SET UP
- LLC and Corporation formation
- Business licensing and permits
- EIN registration
- Business structure consulting
- Registered agent services

4. CREDIT REPAIR
- Credit report analysis and dispute
- Debt negotiation strategies
- Credit rebuilding guidance
- Identity theft resolution

5. GRAPHIC DESIGN
- Logo design and branding
- Marketing materials (flyers, brochures, business cards)
- Social media graphics
- Website design assistance

6. BUSINESS CONSULTING
- Business planning and strategy
- Financial consulting
- Operational improvements
- Growth strategies

7. NOTARY SERVICES
- Document notarization
- Loan signing services
- Mobile notary available
- Apostille services

8. INSURANCE SERVICES
- Auto insurance
- Homeowners insurance
- Renters insurance
- Commercial/Business insurance (General Liability, Workers Comp, Commercial Auto)
- Health insurance (Individual and Family)
- Life insurance (Final expenses, Income replacement, Mortgage protection, Wealth planning)

SPECIAL OFFER:
$100 Coupon available for new clients!

GUIDELINES:
- Be warm, professional, and helpful
- Keep responses concise but informative (2-3 sentences when possible)
- Always encourage calling 239-832-5356 or visiting the Contact page to schedule a consultation
- If asked about pricing, explain that pricing varies based on individual needs and encourage a free consultation
- If you don't know something specific, acknowledge it and suggest contacting the office directly
- Mention the $100 coupon when appropriate
- Focus on the services listed above - do not make up services or capabilities`;

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    console.log('Sending request to Lovable AI with messages:', messages.length);

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          ...messages,
        ],
        max_tokens: 500,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('AI gateway error:', response.status, errorText);
      
      if (response.status === 429) {
        return new Response(JSON.stringify({ 
          error: 'Our chat assistant is busy right now. Please call us at 239-832-5356 for immediate assistance.' 
        }), {
          status: 429,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      
      if (response.status === 402) {
        return new Response(JSON.stringify({ 
          error: 'Chat service temporarily unavailable. Please call us at 239-832-5356.' 
        }), {
          status: 402,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    console.log('Received response from AI');
    
    const assistantMessage = data.choices?.[0]?.message?.content;
    
    if (!assistantMessage) {
      throw new Error('No response from AI');
    }

    return new Response(JSON.stringify({ message: assistantMessage }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Chat assistant error:', error);
    return new Response(JSON.stringify({ 
      error: 'I apologize, but I\'m having trouble responding right now. Please call us at 239-832-5356 for assistance.' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
